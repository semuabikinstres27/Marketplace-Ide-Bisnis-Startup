const { createApp, ref } = Vue;

const app = createApp({
    setup() {
        const ideas = ref([
            { title: 'Aplikasi Belanja Berbasis AI', description: 'Platform yang merekomendasikan produk sesuai dengan kebiasaan belanja pengguna.', rating: 4.5 },
            { title: 'Layanan Konsultasi Kesehatan Online', description: 'Startup yang menghubungkan pasien dengan dokter spesialis melalui video call.', rating: 4.8 }
        ]);

        const newIdea = ref({ title: '', description: '', rating: 0 });

        const addIdea = () => {
            if (newIdea.value.title && newIdea.value.description) {
                ideas.value.push({ ...newIdea.value, rating: 0 });
                newIdea.value = { title: '', description: '', rating: 0 };
            }
        };

        return { ideas, newIdea, addIdea };
    },
    template: `
    <div class='min-h-screen bg-gray-100 p-5'>
        <h1 class='text-3xl font-bold text-center mb-5'>Marketplace Ide Bisnis Startup</h1>
        <div class='max-w-4xl mx-auto bg-white p-6 rounded-xl shadow-md'>
            <h2 class='text-2xl font-semibold mb-3'>Daftar Ide Bisnis</h2>
            <ul>
                <li v-for='(idea, index) in ideas' :key='index' class='p-4 border-b'>
                    <h3 class='text-xl font-bold'>{{ idea.title }}</h3>
                    <p class='text-gray-600'>{{ idea.description }}</p>
                    <p class='text-yellow-500 font-semibold'>⭐ {{ idea.rating }}</p>
                </li>
            </ul>
        </div>
        
        <div class='max-w-4xl mx-auto bg-white p-6 mt-6 rounded-xl shadow-md'>
            <h2 class='text-2xl font-semibold mb-3'>Tambah Ide Bisnis</h2>
            <input v-model='newIdea.title' type='text' placeholder='Judul Ide' class='w-full p-2 border rounded mb-2' />
            <textarea v-model='newIdea.description' placeholder='Deskripsi Ide' class='w-full p-2 border rounded mb-2'></textarea>
            <button @click='addIdea' class='bg-blue-500 text-white px-4 py-2 rounded'>Tambah Ide</button>
        </div>
    </div>`
});

app.mount('#app');